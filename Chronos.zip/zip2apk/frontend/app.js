'use strict';
const $ = (id) => document.getElementById(id);
let token = sessionStorage.getItem('z2a-token') || '';
let job = null, since = 0, poller = null, iconFile = null, health = null, apkName = 'app-debug.apk';

function headers(extra) { const h = Object.assign({}, extra); if (token) h.Authorization = 'Bearer ' + token; return h; }
async function api(path, opts = {}) {
  const res = await fetch(path, Object.assign({}, opts, { headers: headers(opts.headers) }));
  let body = null; try { body = await res.json(); } catch (_) {}
  if (!res.ok) {
    const msg = (body && body.error && body.error.message) || (body && body.detail && (Array.isArray(body.detail) ? body.detail.map(d => d.msg).join('; ') : body.detail)) || ('Request failed (' + res.status + ')');
    throw new Error(msg);
  }
  return body;
}
function show(id, on = true) { $(id).hidden = !on; }
function fmtBytes(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
function fill(ul, items) { ul.replaceChildren(...items.map(t => { const li = document.createElement('li'); li.textContent = t; return li; })); }

async function init() {
  try {
    health = await api('/api/health');
    $('max-mb').textContent = health.limits.max_upload_mb;
    const chip = $('builder-status'); chip.hidden = false;
    const ready = health.web_builds || health.android_builds;
    chip.className = 'chip ' + (ready ? 'good' : 'bad');
    chip.textContent = ready
      ? 'Builder ready · ' + [health.android_builds && 'Android projects', health.web_builds && 'websites'].filter(Boolean).join(' + ')
      : 'Builder not ready: ' + health.reasons.join(' ');
    if (health.limits.auth_required) show('auth');
  } catch (e) { $('up-error').textContent = e.message; show('up-error'); }
}
$('token').value = token;
$('token').addEventListener('input', (e) => { token = e.target.value.trim(); sessionStorage.setItem('z2a-token', token); });

// ---- upload
const drop = $('drop');
['dragover', 'dragenter'].forEach(ev => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', (e) => { if (e.dataTransfer.files[0]) upload(e.dataTransfer.files[0]); });
drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); $('file').click(); } });
$('file').addEventListener('change', (e) => { if (e.target.files[0]) upload(e.target.files[0]); });

function upload(file) {
  show('up-error', false);
  if (!/\.zip$/i.test(file.name)) { $('up-error').textContent = 'Please choose a .zip file.'; show('up-error'); return; }
  const p = $('up-progress'); p.value = 0; show('up-progress');
  const xhr = new XMLHttpRequest();
  xhr.open('PUT', '/api/uploads');
  if (token) xhr.setRequestHeader('Authorization', 'Bearer ' + token);
  xhr.setRequestHeader('X-Filename', file.name);
  xhr.setRequestHeader('Content-Type', 'application/zip');
  xhr.upload.onprogress = (e) => { if (e.lengthComputable) p.value = (e.loaded / e.total) * 100; };
  xhr.onerror = () => { $('up-error').textContent = 'Network error while uploading.'; show('up-error'); show('up-progress', false); };
  xhr.onload = () => {
    show('up-progress', false);
    let body = null; try { body = JSON.parse(xhr.responseText); } catch (_) {}
    if (xhr.status !== 200) {
      $('up-error').textContent = (body && body.error && body.error.message) || (body && body.detail) || ('Upload failed (' + xhr.status + ')');
      show('up-error'); return;
    }
    job = body; since = 0; showReview(file.name);
  };
  xhr.send(file);
}

// ---- review
function showReview(name) {
  show('step-upload', false); show('step-configure');
  const d = job.detection, info = d.info || {};
  $('file-name').textContent = name;
  const badge = $('kind-badge');
  badge.className = 'badge' + (d.kind === 'android' || d.kind === 'web' ? '' : ' bad');
  badge.textContent = { android: 'Android project', web: 'Website', unsupported: 'Unsupported', unknown: 'Unrecognised' }[d.kind];
  const facts = [];
  if (d.kind === 'android') {
    facts.push(['Project root', d.root], ['App module', info.app_module || 'not found'], ['Android Gradle Plugin', info.agp || 'unknown'], ['Gradle to use', info.gradle], ['Gradle wrapper', info.has_wrapper ? 'present (replaced by trusted copy)' : 'missing (supplied)']);
  } else if (d.kind === 'web') {
    facts.push(['Site root', d.root], ['Start page', info.entry], ['Files', String(info.files)], ['Size', fmtBytes(info.bytes)], ['External resources', info.uses_external_resources ? 'yes (CDN/API/fonts)' : 'none detected']);
  }
  $('facts').replaceChildren(...facts.flatMap(([k, v]) => { const dt = document.createElement('dt'), dd = document.createElement('dd'); dt.textContent = k; dd.textContent = v; return [dt, dd]; }));
  fill($('warnings'), d.warnings || []);
  const plan = info.plan || []; show('plan-wrap', plan.length > 0); fill($('plan'), plan.map(p => p.message));
  const ok = d.kind === 'android' || d.kind === 'web';
  $('unsupported').textContent = d.reason || ''; show('unsupported', !ok);
  show('options', d.kind === 'web'); show('android-note', d.kind === 'android'); show('convert', ok);
  if (d.kind === 'web') {
    $('o-name').value = info.suggested_name; $('o-pkg').value = 'com.zip2apk.' + (info.suggested_name.toLowerCase().replace(/[^a-z0-9]/g, '') || 'app').replace(/^(\d)/, 'app$1').slice(0, 40);
    $('o-internet').checked = true;
    $('internet-note').textContent = info.uses_external_resources ? ' — your site loads external resources, keep this on' : ' — your site appears fully self-contained';
  }
  if (!ok) { const again = document.createElement('button'); again.textContent = 'Try another ZIP'; again.onclick = reset; $('step-configure').append(again); }
}
document.querySelectorAll('input[name=icon]').forEach(r => r.addEventListener('change', () => { if (r.checked && r.value === 'upload') $('o-icon').click(); }));
$('o-icon').addEventListener('change', (e) => {
  iconFile = e.target.files[0] || null;
  if (iconFile) { const img = $('icon-preview'); img.src = URL.createObjectURL(iconFile); img.hidden = false; }
});

// ---- build
$('convert').addEventListener('click', async () => {
  const btn = $('convert'); btn.disabled = true;
  try {
    let opts = {};
    if (job.detection.kind === 'web') {
      const mode = document.querySelector('input[name=icon]:checked').value;
      if (mode === 'upload') {
        if (!iconFile) throw new Error('Choose an icon image or pick another icon option.');
        await api('/api/jobs/' + job.id + '/icon', { method: 'PUT', body: iconFile });
      }
      opts = {
        app_name: $('o-name').value.trim(), package_name: $('o-pkg').value.trim(), version_name: $('o-vname').value.trim() || '1.0.0',
        version_code: parseInt($('o-vcode').value, 10) || 1, internet: $('o-internet').checked, orientation: $('o-orient').value,
        theme_color: $('o-color').value, icon_mode: mode, spa_fallback: $('o-spa').checked,
      };
    }
    const v = await api('/api/jobs/' + job.id + '/build', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(opts) });
    show('step-configure', false); show('step-build'); show('result', false); show('failure', false); $('log').textContent = '';
    since = 0; render(v); poll();
  } catch (e) { alert(e.message); btn.disabled = false; }
});

function poll() {
  clearTimeout(poller);
  poller = setTimeout(async () => {
    try { const v = await api('/api/jobs/' + job.id + '?since=' + since); render(v); if (v.status === 'queued' || v.status === 'running') poll(); }
    catch (e) { $('build-status').textContent = 'Connection problem: ' + e.message + ' (retrying)'; poll(); }
  }, 1000);
}

function render(v) {
  const order = ['queued', 'prepare', 'gradle', 'collect'];
  const cur = v.status === 'queued' ? 'queued' : v.stage;
  const idx = v.status === 'succeeded' ? 4 : order.indexOf(cur);
  document.querySelectorAll('#stages li').forEach((li, i) => { li.className = i < idx ? 'done' : i === idx ? 'active' : ''; });
  $('build-progress').value = v.progress;
  $('build-status').textContent = v.status === 'queued' ? 'Queued' + (v.queue_position ? ' (position ' + v.queue_position + ')' : '') + '…'
    : v.status === 'running' ? (v.current_task ? 'Running ' + v.current_task : 'Working…') : '';
  if (v.log && v.log.length) {
    const el = $('log'), stick = el.scrollTop + el.clientHeight >= el.scrollHeight - 30;
    el.textContent += v.log.join('\n') + '\n'; if (stick) el.scrollTop = el.scrollHeight;
  }
  since = v.next;
  if (v.status === 'succeeded') {
    show('result'); $('result-text').textContent = 'Build succeeded.'; apkName = v.apk.name;
    $('apk-meta').textContent = v.apk.name + ' · ' + fmtBytes(v.apk.size) + ' · SHA-256 ' + v.apk.sha256.slice(0, 16) + '…';
    $('build-status').textContent = '';
  } else if (v.status === 'failed') {
    show('failure'); $('failure-text').textContent = (v.error && v.error.message) || 'The build failed.';
    fill($('hints'), (v.error && v.error.hints) || []); $('build-status').textContent = '';
  }
}

$('download').addEventListener('click', async () => {
  try {
    const res = await fetch('/api/jobs/' + job.id + '/apk', { headers: headers() });
    if (!res.ok) throw new Error('Download failed (' + res.status + ')');
    const a = document.createElement('a'); a.href = URL.createObjectURL(await res.blob()); a.download = apkName;
    document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  } catch (e) { alert(e.message); }
});
$('copy-log').addEventListener('click', () => navigator.clipboard && navigator.clipboard.writeText($('log').textContent));
function reset() { clearTimeout(poller); if (job) api('/api/jobs/' + job.id, { method: 'DELETE' }).catch(() => {}); location.reload(); }
$('again').addEventListener('click', reset);
init();
