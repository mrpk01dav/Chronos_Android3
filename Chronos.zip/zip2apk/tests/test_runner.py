"""Tests the real subprocess runner + builder/build.sh using a stand-in `gradle` executable.
(The genuine Gradle/Android SDK run needs the Docker builder image; see README.)"""
import asyncio
import os
import stat
import sys
import tempfile
import unittest
import zipfile
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))
from app import builder, config  # noqa: E402

FAKE_GRADLE = """#!/usr/bin/env bash
MODE=$(cat .fake_mode 2>/dev/null || echo ok)
echo "> Task :app:preBuild"
echo "> Task :app:compileDebugKotlin"
if [[ "$MODE" == "fail" ]]; then
  printf 'e: file:///x/A.kt:1:1 Unresolved reference: nope\\n* What went wrong:\\nExecution failed for task compile.\\n\\n* Try:\\n'
  exit 1
fi
if [[ "$MODE" == "hang" ]]; then sleep 30; fi
mkdir -p app/build/outputs/apk/debug
python3 - <<'PY'
import zipfile
with zipfile.ZipFile("app/build/outputs/apk/debug/app-debug.apk","w") as z:
    z.writestr("AndroidManifest.xml","x"); z.writestr("classes.dex","x"); z.writestr("META-INF/CERT.RSA","x")
PY
echo "> Task :app:assembleDebug"
"""


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        gh = self.tmp / "gradle-home" / "bin"
        gh.mkdir(parents=True)
        g = gh / "gradle"
        g.write_text(FAKE_GRADLE)
        g.chmod(g.stat().st_mode | stat.S_IEXEC)
        os.environ.update({"ZIP2APK_RUNNER": "local", "ZIP2APK_ANDROID_HOME": str(self.tmp / "sdk"),
                           "ZIP2APK_GRADLE_HOME": str(self.tmp / "gradle-home"), "ZIP2APK_BUILD_TIMEOUT_SEC": "60"})
        (self.tmp / "sdk").mkdir()
        self.s = config.load()
        job = self.tmp / "job"
        (job / "project").mkdir(parents=True)
        (job / "out").mkdir()
        self.spec = builder.BuildSpec("abcdefghijklmnop1234", job / "project", job / "out", "8.9", "assembleDebug", True)

    def run_it(self, mode, settings=None):
        (self.spec.project_dir / ".fake_mode").write_text(mode)
        lines = []
        res = asyncio.run(builder.run_build(settings or self.s, self.spec, lines.append))
        return res, lines

    def test_success(self):
        res, lines = self.run_it("ok")
        self.assertTrue(res.ok, res)
        self.assertEqual(res.apk.name, "app-debug.apk")
        self.assertIn("##Z2A:STAGE:collect", lines)
        self.assertEqual(builder.validate_apk(res.apk)["signed"], True)
        sdk_line = (self.spec.project_dir / "local.properties").read_text()
        self.assertIn(str(self.tmp / "sdk"), sdk_line)

    def test_failure_diagnosed(self):
        res, _ = self.run_it("fail")
        self.assertFalse(res.ok)
        self.assertEqual(res.error_code, "build_failed")
        self.assertIn("Execution failed", res.message)
        self.assertTrue(any("Kotlin" in h for h in res.hints))

    def test_timeout_kills_process_group(self):
        res, _ = self.run_it("hang", replace(self.s, build_timeout=2))
        self.assertTrue(res.timed_out)
        self.assertEqual(res.error_code, "timeout")

    def test_untrusted_refused_on_local_runner(self):
        spec = replace(self.spec, trusted=False)
        res = asyncio.run(builder.run_build(self.s, spec, lambda l: None))
        self.assertEqual(res.error_code, "unsafe_runner")

    def test_bad_gradle_version_rejected_by_script(self):
        spec = replace(self.spec, gradle_version="8.9; rm -rf /")
        res = asyncio.run(builder.run_build(self.s, spec, lambda l: None))
        self.assertFalse(res.ok)


if __name__ == "__main__":
    unittest.main()
