"""Unit tests for everything except the real Gradle run (which needs Docker + Android SDK)."""
import asyncio
import io
import os
import sys
import tempfile
import unittest
import xml.dom.minidom as minidom
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))

from app import androidfix, builder, config, detector, jobs, safezip, webwrap  # noqa: E402

LIM = safezip.Limits(1000, 50 << 20, 20 << 20, 200)
TEMPLATE = ROOT / "backend" / "app" / "templates" / "webview"


def make_zip(path, files, extra=None):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files.items():
            z.writestr(name, data)
        if extra:
            extra(z)


class SafeZipTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def extract(self, files, extra=None, lim=LIM):
        z = self.tmp / "t.zip"
        make_zip(z, files, extra)
        return safezip.safe_extract(z, self.tmp / "out", lim)

    def test_ok(self):
        r = self.extract({"a/b.txt": "hi", "__MACOSX/x": "junk", ".DS_Store": "x"})
        self.assertEqual(r.files, 1)
        self.assertTrue((self.tmp / "out/a/b.txt").is_file())

    def test_traversal(self):
        for bad in ("../evil.txt", "a/../../evil.txt", "/etc/passwd", "C:/x.txt", "..\\evil.txt"):
            with self.subTest(bad), self.assertRaises(safezip.ZipRejected) as cm:
                self.extract({bad: "x"})
            self.assertEqual(cm.exception.code, "unsafe_path")
        self.assertFalse((self.tmp / "evil.txt").exists())

    def test_symlink(self):
        def add(z):
            i = zipfile.ZipInfo("link")
            i.external_attr = (0o120777 << 16)
            z.writestr(i, "/etc/passwd")
        with self.assertRaises(safezip.ZipRejected) as cm:
            self.extract({}, add)
        self.assertEqual(cm.exception.code, "symlink")

    def test_bomb_and_limits(self):
        with self.assertRaises(safezip.ZipRejected) as cm:
            self.extract({"z.bin": b"\0" * (10 << 20)})
        self.assertEqual(cm.exception.code, "zip_bomb")
        with self.assertRaises(safezip.ZipRejected) as cm:
            self.extract({f"f{i}": "x" for i in range(20)}, lim=safezip.Limits(10, 1 << 20, 1 << 20, 200))
        self.assertEqual(cm.exception.code, "too_many_entries")

    def test_not_zip(self):
        p = self.tmp / "n.zip"
        p.write_bytes(b"not a zip")
        with self.assertRaises(safezip.ZipRejected):
            safezip.safe_extract(p, self.tmp / "o", LIM)

    def test_duplicate(self):
        with self.assertRaises(safezip.ZipRejected) as cm:
            self.extract({}, lambda z: (z.writestr("a", "1"), z.writestr("a", "2")))
        self.assertEqual(cm.exception.code, "duplicate_entry")


ANDROID_FILES = {
    "settings.gradle.kts": 'rootProject.name = "X"\ninclude(":app")\n',
    "build.gradle.kts": "plugins { alias(libs.plugins.android.application) apply false }",
    "gradle/libs.versions.toml": '[versions]\nagp = "8.5.2"\n[libraries]\nx = { group = "androidx.core", name = "core-ktx", version = "1" }\n',
    "app/build.gradle.kts": 'plugins { alias(libs.plugins.android.application) }\nandroid { namespace = "a.b" }',
    "app/src/main/AndroidManifest.xml": '<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:label="Demo" android:icon="@mipmap/ic_launcher" android:theme="@style/Theme.Demo" android:fullBackupContent="@xml/backup_rules"/></manifest>',
}


class DetectorTests(unittest.TestCase):
    def detect(self, files):
        d = Path(tempfile.mkdtemp())
        for k, v in files.items():
            p = d / k
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(v)
        return d, detector.detect(d, "8.9")

    def test_android_and_repair(self):
        d, det = self.detect(ANDROID_FILES)
        self.assertEqual(det.kind, "android")
        self.assertEqual(det.info["app_module"], ":app")
        self.assertEqual(det.info["gradle"], "8.7")  # AGP 8.5 -> Gradle 8.7, bundled is 8.9
        acts = androidfix.analyze(d, Path(det.info["_app_dir"]), det.info["gradle"], False)
        androidfix.apply(acts)
        res = d / "app/src/main/res"
        self.assertTrue((res / "mipmap-xxhdpi/ic_launcher.png").is_file())
        self.assertTrue((res / "xml/backup_rules.xml").is_file())
        self.assertIn("Theme.Demo", (res / "values/z2a_generated_themes.xml").read_text())
        self.assertIn("android.useAndroidX=true", (d / "gradle.properties").read_text())
        for x in res.rglob("*.xml"):
            minidom.parse(str(x))
        # idempotent: nothing left to fix
        again = [a for a in androidfix.analyze(d, Path(det.info["_app_dir"]), "8.7", True) if a.kind == "fix"]
        self.assertEqual(again, [])

    def test_nested_root(self):
        _, det = self.detect({"Proj/" + k: v for k, v in ANDROID_FILES.items()})
        self.assertEqual(det.kind, "android")
        self.assertEqual(det.root.name, "Proj")

    def test_web(self):
        _, det = self.detect({"site/index.html": "<title>Hello &amp; Co</title><script src='https://cdn.x/y.js'></script>", "site/a.css": ""})
        self.assertEqual(det.kind, "web")
        self.assertEqual(det.info["suggested_name"], "Hello & Co")
        self.assertTrue(det.info["uses_external_resources"])

    def test_unbuilt_vite_warns(self):
        _, det = self.detect({"index.html": '<script type="module" src="/src/main.jsx"></script>', "package.json": '{"scripts":{"build":"vite build"}}'})
        self.assertEqual(det.kind, "web")
        self.assertTrue(any("unbuilt" in w for w in det.warnings))

    def test_unsupported(self):
        self.assertEqual(self.detect({"pubspec.yaml": "name: x"})[1].kind, "unsupported")
        self.assertEqual(self.detect({"package.json": '{"dependencies":{"react-native":"1"}}'})[1].kind, "unsupported")
        self.assertEqual(self.detect({"readme.txt": "x"})[1].kind, "unknown")

    def test_gradle_selection(self):
        self.assertEqual(detector.required_gradle("8.7.2", None, "8.9"), "8.9")
        self.assertEqual(detector.required_gradle("8.7.2", "8.12", "8.9"), "8.12")
        self.assertEqual(detector.required_gradle("8.7.2", "8.0", "8.9"), "8.9")
        self.assertEqual(detector.required_gradle(None, None, "8.9"), "8.9")


class WebWrapTests(unittest.TestCase):
    def test_package_validation(self):
        webwrap.validate_package("com.example.app")
        for bad in ("app", "Com.Example", "com.1abc", "com.class.x", "com.exa mple"):
            with self.subTest(bad), self.assertRaises(webwrap.OptionError):
                webwrap.validate_package(bad)

    def test_android_string_escaping(self):
        self.assertEqual(webwrap.android_string("Tom's <App> & \"co\""), "Tom\\'s &lt;App&gt; &amp; \\\"co\\\"")
        self.assertEqual(webwrap.android_string("@home"), "\\@home")

    def generate(self, internet=True, name="Tom's App"):
        site = Path(tempfile.mkdtemp())
        (site / "index.html").write_text("<title>t</title>")
        (site / "_next/static").mkdir(parents=True)
        (site / "_next/static/a.js").write_text("1")
        (site / "node_modules").mkdir()
        (site / "node_modules/x.js").write_text("1")
        out = Path(tempfile.mkdtemp()) / "p"
        notes = webwrap.generate_project(site, "index.html", out, webwrap.WebOptions(name, "com.t.app", internet=internet, orientation="portrait"), TEMPLATE)
        return out, notes

    def test_generation(self):
        out, _ = self.generate()
        main = out / "app/src/main"
        manifest = (main / "AndroidManifest.xml").read_text()
        self.assertIn("android.permission.INTERNET", manifest)
        self.assertIn('screenOrientation="portrait"', manifest)
        self.assertNotIn("{{", manifest)
        for x in list(main.rglob("*.xml")):
            minidom.parse(str(x))
        self.assertTrue((main / "assets/www/_next/static/a.js").is_file())  # underscore dirs survive
        self.assertFalse((main / "assets/www/node_modules").exists())
        self.assertIn("com.t.app", (out / "gradle.properties").read_text())
        self.assertIn("Tom\\'s App", (main / "res/values/strings.xml").read_text())
        self.assertTrue((main / "res/mipmap-xxxhdpi/ic_launcher_round.png").is_file())

    def test_no_internet(self):
        out, notes = self.generate(internet=False)
        self.assertNotIn("INTERNET", (out / "app/src/main/AndroidManifest.xml").read_text())
        self.assertTrue(any("Internet permission is OFF" in n for n in notes))


class BuilderTests(unittest.TestCase):
    def test_progress_parse(self):
        self.assertEqual(builder.parse_line("##Z2A:STAGE:gradle")[:2], ("gradle", 20))
        self.assertEqual(builder.parse_line("> Task :app:compileDebugKotlin")[1:], (60, ":app:compileDebugKotlin"))

    def test_diagnose(self):
        log = "e: file:///x/Main.kt:3:1 Unresolved reference: foo\n* What went wrong:\nExecution failed for task ':app:compileDebugKotlin'.\n> Compilation error. See log for more details\n\n* Try:\n"
        hints = builder.diagnose(log)
        self.assertTrue(any("Kotlin compilation" in h for h in hints))
        self.assertIn("Execution failed", builder.what_went_wrong(log))
        self.assertTrue(any("could not be downloaded" in h for h in builder.diagnose("Could not resolve com.x:y:1")))

    def test_validate_apk(self):
        p = Path(tempfile.mkdtemp()) / "a.apk"
        make_zip(p, {"AndroidManifest.xml": "x", "classes.dex": "x", "META-INF/CERT.RSA": "x"})
        self.assertTrue(builder.validate_apk(p)["signed"])
        make_zip(p, {"foo": "x"})
        with self.assertRaises(ValueError):
            builder.validate_apk(p)


class JobFlowTests(unittest.TestCase):
    """Exercises upload->inspect->build plumbing with a stub runner (no Gradle available in CI)."""

    def run_flow(self, files, options, runner):
        data = Path(tempfile.mkdtemp())
        os.environ["ZIP2APK_DATA_DIR"] = str(data)
        s = config.load()
        mgr = jobs.JobManager(s, runner)

        async def go():
            await mgr.start()
            job = mgr.create("1.2.3.4")
            make_zip(job.dir / "upload.zip", files)
            await asyncio.to_thread(mgr.inspect, job)
            caps = {"web_builds": True, "android_builds": True, "reasons": []}
            mgr.enqueue(job, options, caps)
            for _ in range(200):
                await asyncio.sleep(0.05)
                if job.status in ("succeeded", "failed"):
                    break
            await mgr.stop()
            return job, mgr

        return asyncio.run(go())

    WEB_OPTS = dict(app_name="Demo", package_name="com.demo.app", version_name="1.0.0", version_code=1, internet=True,
                    orientation="auto", theme_color="#3b5bdb", icon_mode="auto", spa_fallback=True)

    def test_web_success_and_cleanup(self):
        async def stub(s, spec, on_line):
            self.assertTrue((spec.project_dir / "app/src/main/assets/www/index.html").is_file())
            on_line("##Z2A:STAGE:gradle")
            on_line("> Task :app:compileDebugJavaWithJavac")
            apk = spec.out_dir / "app-debug.apk"
            make_zip(apk, {"AndroidManifest.xml": "x", "classes.dex": "x", "META-INF/CERT.RSA": "x"})
            return builder.BuildResult(True, 0, apk)
        job, mgr = self.run_flow({"index.html": "<title>x</title>"}, self.WEB_OPTS, stub)
        self.assertEqual(job.status, "succeeded", job.error)
        self.assertEqual(job.progress, 100)
        self.assertFalse((job.dir / "project").exists())  # temp build tree removed
        self.assertFalse((job.dir / "src").exists())
        self.assertTrue(job.apk.is_file())
        self.assertTrue(mgr.view(job)["apk"]["signed"])

    def test_failure_surfaces_diagnostics(self):
        async def stub(s, spec, on_line):
            return builder.BuildResult(False, 1, error_code="build_failed", message="boom", hints=["hint"])
        job, _ = self.run_flow({"index.html": "<title>x</title>"}, self.WEB_OPTS, stub)
        self.assertEqual(job.status, "failed")
        self.assertEqual(job.error["hints"], ["hint"])

    def test_android_prepared_before_build(self):
        seen = {}

        async def stub(s, spec, on_line):
            seen["task"] = spec.gradle_task
            seen["gradle"] = spec.gradle_version
            seen["trusted"] = spec.trusted
            seen["icon"] = (spec.project_dir / "app/src/main/res/mipmap-mdpi/ic_launcher.png").is_file()
            return builder.BuildResult(False, 1, error_code="build_failed", message="x")
        self.run_flow(ANDROID_FILES, {}, stub)
        self.assertEqual(seen, {"task": ":app:assembleDebug", "gradle": "8.7", "trusted": False, "icon": True})

    def test_rejects_traversal_upload(self):
        data = Path(tempfile.mkdtemp())
        os.environ["ZIP2APK_DATA_DIR"] = str(data)
        mgr = jobs.JobManager(config.load())
        job = mgr.create("x")
        make_zip(job.dir / "upload.zip", {"../x": "1"})
        with self.assertRaises(jobs.JobError):
            mgr.inspect(job)
        self.assertNotIn(job.id, mgr.jobs)


class RealChronosZip(unittest.TestCase):
    ZIP = Path("/mnt/user-data/uploads/Chronos-Native-Android-Project__1_.zip")

    @unittest.skipUnless(ZIP.is_file(), "sample ZIP not present")
    def test_chronos(self):
        d = Path(tempfile.mkdtemp())
        safezip.safe_extract(self.ZIP, d, LIM)
        det = detector.detect(d, "8.9")
        self.assertEqual((det.kind, det.info["agp"], det.info["gradle"]), ("android", "8.7.2", "8.9"))
        msgs = " ".join(a.message for a in androidfix.analyze(d, Path(det.info["_app_dir"]), "8.9", False))
        for needle in ("useAndroidX", "ic_launcher", "backup_rules", "Theme.Chronos"):
            self.assertIn(needle, msgs)


if __name__ == "__main__":
    unittest.main()
