#!/usr/bin/env bash
# Runs inside the sandbox (docker image) or, for trusted dev use, on the host.
# Inputs (env): WORKDIR OUTDIR GRADLE_TASK GRADLE_VERSION ANDROID_HOME GRADLE_HOME WRAPPER_TEMPLATE BUNDLED_GRADLE_VERSION
# Emits "##Z2A:..." marker lines that the backend parses for progress.
set -uo pipefail

: "${WORKDIR:?}" "${OUTDIR:?}" "${GRADLE_TASK:?}" "${ANDROID_HOME:?}" "${GRADLE_HOME:?}" "${BUNDLED_GRADLE_VERSION:?}"
GRADLE_VERSION="${GRADLE_VERSION:-$BUNDLED_GRADLE_VERSION}"

[[ "$GRADLE_VERSION" =~ ^[0-9]+(\.[0-9]+){1,2}$ ]] || { echo "Invalid GRADLE_VERSION"; exit 64; }
[[ "$GRADLE_TASK" =~ ^[A-Za-z0-9:_-]+$ ]]          || { echo "Invalid GRADLE_TASK"; exit 64; }

cd "$WORKDIR" || exit 66
echo "##Z2A:STAGE:prepare"
echo "Java: $(java -version 2>&1 | head -1)"

# Never trust machine-specific files or wrapper binaries that came with the upload.
printf 'sdk.dir=%s\n' "$ANDROID_HOME" > local.properties
rm -f gradlew gradlew.bat gradle/wrapper/gradle-wrapper.jar

# Optional persistent debug keystore so successive APKs share one signature.
if [[ -n "${DEBUG_KEYSTORE:-}" && -f "$DEBUG_KEYSTORE" ]]; then
  mkdir -p "${ANDROID_USER_HOME:-$HOME/.android}"
  cp "$DEBUG_KEYSTORE" "${ANDROID_USER_HOME:-$HOME/.android}/debug.keystore"
fi

if [[ "$GRADLE_VERSION" == "$BUNDLED_GRADLE_VERSION" ]]; then
  GRADLE_CMD="$GRADLE_HOME/bin/gradle"
else
  : "${WRAPPER_TEMPLATE:?wrapper template required for Gradle $GRADLE_VERSION}"
  mkdir -p gradle/wrapper
  cp "$WRAPPER_TEMPLATE/gradlew" "$WRAPPER_TEMPLATE/gradlew.bat" .
  cp "$WRAPPER_TEMPLATE/gradle/wrapper/gradle-wrapper.jar" gradle/wrapper/
  cat > gradle/wrapper/gradle-wrapper.properties <<PROPS
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
PROPS
  chmod +x gradlew
  GRADLE_CMD="./gradlew"
fi
echo "Using Gradle $GRADLE_VERSION, task $GRADLE_TASK"

echo "##Z2A:STAGE:gradle"
"$GRADLE_CMD" "$GRADLE_TASK" --no-daemon --console=plain --max-workers=2 --warning-mode=summary
rc=$?
echo "##Z2A:GRADLE_EXIT:$rc"
[[ $rc -eq 0 ]] || exit "$rc"

echo "##Z2A:STAGE:collect"
mkdir -p "$OUTDIR"
found=0
while IFS= read -r -d '' apk; do
  case "$apk" in *unaligned*) continue;; esac
  cp "$apk" "$OUTDIR/" && found=$((found + 1)) && echo "APK: $apk"
done < <(find . -path '*/build/outputs/apk/debug/*.apk' -print0)
if [[ $found -eq 0 ]]; then
  echo "Gradle finished successfully but no debug APK was produced (is this an application module?)."
  exit 65
fi
exit 0
