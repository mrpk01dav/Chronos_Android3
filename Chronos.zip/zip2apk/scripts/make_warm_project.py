#!/usr/bin/env python3
"""Render the web-wrapper template with dummy values into builder/warm-project/ so the Docker image
can pre-download every dependency the wrapper needs."""
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))
from app import webwrap  # noqa: E402

dst = ROOT / "builder" / "warm-project"
if dst.exists():
    shutil.rmtree(dst)
with tempfile.TemporaryDirectory() as t:
    site = Path(t)
    (site / "index.html").write_text("<!doctype html><title>warm</title>", encoding="utf-8")
    webwrap.generate_project(site, "index.html", dst, webwrap.WebOptions("Warm", "com.zip2apk.warm"),
                             ROOT / "backend" / "app" / "templates" / "webview")
print("warm project written to", dst)
