# ZIP → APK Converter

Upload a ZIP, get a **debug APK** built by the real Android toolchain (JDK 17 + Android SDK + Gradle).
No mock builds: the backend runs Gradle inside a locked-down container and returns the file Gradle produced.

| ZIP contains | What happens |
|---|---|
| **Android Studio project** (`settings.gradle[.kts]`) | Extracted → minimal automatic repairs (see below) → `:app:assembleDebug` with Gradle matched to the project's AGP version |
| **Website** (`index.html` + assets, or a `dist/` / `build/` folder) | A new Android project is generated from a template (WebView + `WebViewAssetLoader`, your files bundled as assets) → `assembleDebug` |
| Flutter, React Native, Unity, source-only Node projects, encrypted ZIPs, ZIPs with symlinks | Rejected with an explanation |

## Architecture

```
browser ──PUT /api/uploads──► safezip (validate+extract) ─► detector ─► job (inspected)
        ──POST /build──────► queue ─► worker ─► [web: webwrap.generate | android: androidfix.apply]
                                          └─► docker run zip2apk-builder  (build.sh → gradle)  ─► APK
        ◄─GET /api/jobs/{id} (polling: stage, progress, log lines, diagnostics)
        ◄─GET /api/jobs/{id}/apk
```

* `backend/app/safezip.py` – path traversal, absolute/drive paths, symlinks, special files, encrypted entries, duplicate entries, entry-count / per-file / total size caps, zip-bomb ratio, streaming byte counters (header sizes are not trusted).
* `detector.py` – classifies the ZIP, finds the project root (handles a single wrapper folder), app module, AGP and Gradle versions.
* `androidfix.py` – fixes only what makes exported projects fail for non-code reasons: missing launcher icons, `backup_rules` / `data_extraction_rules` XML, a missing `Theme.*` style, `android.useAndroidX`, `org.gradle.jvmargs`, IDE-specific `org.gradle.java.home`, no Gradle wrapper. It never edits source or dependency versions, and lists every change in the UI and log. Missing resources it cannot invent (e.g. `@drawable/foo`) are reported as warnings.
* `webwrap.py` + `templates/webview/` – generated project: `minSdk 24`, AGP 8.7.2, plain Java `Activity`, serves `assets/www` at `https://appassets.androidplatform.net/` (absolute paths, ES modules and `fetch()` work), clean URLs, optional SPA fallback, file chooser, back-navigation, external links open in the browser, `_next/`-style underscore folders preserved, optional `INTERNET` permission.
* `builder.py` + `builder/build.sh` + `builder/Dockerfile` – sandbox runner, log streaming, stage/progress parsing, timeout kill, APK validation (manifest, dex, signature, SHA-256) and error diagnostics.

## Security model (read this)

**An Android project's Gradle scripts are arbitrary code.** Opening a `build.gradle.kts` runs it. Therefore:

* Docker runner (default): each build is a fresh container with `--cap-drop ALL`, `no-new-privileges`, PID/memory/CPU limits, a tmpfs `/tmp`, only the job's folder mounted, non-root user, and a hard timeout (`docker kill`). Uploaded `gradlew` / `gradle-wrapper.jar` / `local.properties` are deleted and replaced with trusted ones.
* Website builds never run uploaded code: files are copied as assets into *our* template.
* The local runner (`ZIP2APK_RUNNER=local`) builds websites only, unless you set `ZIP2APK_ALLOW_UNSAFE_LOCAL_ANDROID=true` on a disposable machine.
* The container needs outbound network to download dependencies. For a public service restrict egress to `dl.google.com`, `maven.google.com`, `repo.maven.apache.org`, `plugins.gradle.org`, `services.gradle.org` (egress proxy / firewall). Without it a malicious build can reach the internet.
* Docker isolation is container-grade, not VM-grade. For hostile multi-tenant traffic run builders on dedicated hosts or use gVisor/Kata/Firecracker (`--runtime=runsc`) and add authentication (`ZIP2APK_API_TOKEN`) and rate-limits (see `deploy/nginx.conf`).
* Don't mount the Docker socket into a container; run the API on the host (see `deploy/zip2apk.service`).
* Job data is deleted after the build (sources immediately; the APK after `ZIP2APK_JOB_TTL_SEC`, default 1 h).

## Prerequisites

* Linux host with Docker, Python 3.10+. ~6 GB RAM and 2 CPUs free per concurrent build; ~4 GB disk for the image.
* Internet access to build the image and for the builds themselves.

## Setup

```bash
python3 -m venv venv && . venv/bin/activate
pip install -r backend/requirements.txt
make builder            # builds zip2apk-builder (JDK17, SDK 35, Gradle 8.9, pre-warmed dependency cache) — ~10 min once
make run                # http://127.0.0.1:8000
make test               # unit tests (no Docker needed)
```

The UI header shows whether the builder is ready (`GET /api/health`).

### Configuration (`ZIP2APK_*` environment variables)

| Variable | Default | Meaning |
|---|---|---|
| `RUNNER` | `docker` | `docker` or `local` |
| `MAX_UPLOAD_MB` / `MAX_UNZIPPED_MB` / `MAX_FILE_MB` | 100 / 500 / 100 | size limits |
| `MAX_ENTRIES`, `MAX_COMPRESSION_RATIO` | 20000, 200 | zip-bomb guards |
| `BUILD_TIMEOUT_SEC` | 1200 | hard kill |
| `CONCURRENCY`, `MAX_QUEUED`, `MAX_ACTIVE_PER_CLIENT` | 1, 20, 2 | queueing |
| `DOCKER_IMAGE`, `DOCKER_NETWORK`, `DOCKER_MEMORY`, `DOCKER_CPUS` | `zip2apk-builder:latest`, `bridge`, `6g`, `2` | sandbox |
| `DEBUG_KEYSTORE` | – | path to a persistent debug keystore so APKs from different builds share a signature (otherwise every build gets a new debug key) |
| `API_TOKEN` | – | require `Authorization: Bearer …` on every API call |
| `TRUST_PROXY_HEADER` | false | use the last `X-Forwarded-For` hop as client address (only behind your own proxy) |
| `DATA_DIR`, `JOB_TTL_SEC` | `./data`, 3600 | storage |

## Deployment

1. Install Docker, create user `zip2apk` (member of `docker`, or use rootless Docker), copy the repo to `/opt/zip2apk`, create the venv, run `make builder`.
2. Install `deploy/zip2apk.service`, put secrets in `/etc/zip2apk.env` (`ZIP2APK_API_TOKEN=...`), `systemctl enable --now zip2apk`.
3. Put nginx (`deploy/nginx.conf`) with TLS in front; keep uvicorn on 127.0.0.1.
4. Add the egress allow-list for the build network, monitor disk under `DATA_DIR`.

## API

`GET /api/health` · `PUT /api/uploads` (raw ZIP body, `X-Filename` header) → job + detection · `PUT /api/jobs/{id}/icon` (raw PNG/JPEG/WEBP) · `POST /api/jobs/{id}/build` (JSON options; empty `{}` for Android projects) · `GET /api/jobs/{id}?since=N` · `GET /api/jobs/{id}/apk` · `DELETE /api/jobs/{id}`. Interactive docs at `/api/docs`.

## Known limits

* Debug APKs only (debug-signed; install via sideloading). Release signing/AAB are out of scope.
* JDK 17 only; projects pinning another JDK toolchain fail with a clear diagnosis. Gradle versions other than the bundled 8.9 are downloaded per build by the wrapper (slower).
* Android dependencies are downloaded per build unless they are in the image's pre-warmed cache (the web wrapper's are).
* Web wrapper: no service workers, no video seeking from local files, no push notifications; `localStorage`/IndexedDB work. Sites needing APIs must have internet enabled.
* Progress is stage-based: Gradle reports no total.
* Jobs live in memory; a restart discards them.
* The 29 unit tests cover everything except a genuine Gradle run, which needs the Docker image built on a machine with internet access. Do one real build per project type after deploying.
