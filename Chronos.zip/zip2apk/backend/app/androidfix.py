"""Pre-build analysis/repair of Android Studio projects exported without all their files.

Typical ZIPs shared from chats or generators omit res/, gradle.properties and the Gradle wrapper, which makes
the build fail for reasons unrelated to the code. This module plans minimal, clearly-reported fixes:
placeholder launcher icons, backup-rule XMLs, a missing theme, gradle.properties flags, IDE-specific lines.
It never edits source code or changes dependency versions.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from . import icons

_LIB_STYLE = re.compile(r"^(Theme\.(AppCompat|Material|MaterialComponents|Material3|MaterialComponents)|Widget\.|TextAppearance\.)")


@dataclass
class Action:
    kind: str  # "fix" | "info" | "warn"
    message: str
    apply: Callable[[], None] | None = None


def _read(p: Path, limit: int = 400_000) -> str:
    try:
        return p.read_text(encoding="utf-8", errors="replace")[:limit] if p.is_file() else ""
    except OSError:
        return ""


def _res_exists(res: Path, rtype: str, name: str) -> bool:
    if rtype in ("string", "color", "style", "dimen"):
        tag = {"string": "string", "color": "color", "style": "style", "dimen": "dimen"}[rtype]
        variants = {name, name.replace(".", "_")}
        for f in res.glob("values*/*.xml"):
            txt = _read(f)
            if any(re.search(rf"<{tag}\s[^>]*name\s*=\s*\"{re.escape(v)}\"", txt) for v in variants):
                return True
        return False
    for d in res.glob(f"{rtype}*"):
        if d.is_dir() and any(f.stem == name for f in d.iterdir() if f.is_file()):
            return True
    return False


def _humanize(name: str) -> str:
    return re.sub(r"[_.]+", " ", name).strip().title() or "App"


def analyze(project: Path, app_dir: Path | None, gradle_version: str, has_wrapper: bool) -> list[Action]:
    actions: list[Action] = []
    if not has_wrapper:
        actions.append(Action("info", f"No Gradle wrapper in the project: building with Gradle {gradle_version} supplied by the builder."))
    if (project / "local.properties").is_file():
        actions.append(Action("info", "local.properties (machine-specific SDK path) will be ignored and regenerated."))

    # ---- gradle.properties
    gp = project / "gradle.properties"
    gp_text = _read(gp)
    all_gradle = "".join(_read(p) for p in project.rglob("*.gradle*") if "build" not in p.relative_to(project).parts[:-1])
    all_gradle += _read(project / "gradle" / "libs.versions.toml")
    lines = gp_text.splitlines()
    has = lambda key: any(l.strip().startswith(key + "=") for l in lines)  # noqa: E731
    adds: list[str] = []
    if "androidx" in all_gradle and not has("android.useAndroidX"):
        adds.append("android.useAndroidX=true")
    if not has("org.gradle.jvmargs"):
        adds.append("org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8")
    bad = [l for l in lines if l.strip().startswith("org.gradle.java.home")]
    if adds or bad:
        def fix_props(gp=gp, lines=lines, adds=adds):
            kept = [l for l in lines if not l.strip().startswith("org.gradle.java.home")]
            gp.write_text("\n".join(kept + adds) + "\n", encoding="utf-8")
        msg = []
        if adds:
            msg.append("add " + ", ".join(a.split("=")[0] for a in adds) + " to gradle.properties")
        if bad:
            msg.append("remove IDE-specific org.gradle.java.home")
        actions.append(Action("fix", "Will " + " and ".join(msg) + ".", fix_props))

    if app_dir is None:
        return actions

    # ---- manifest-referenced resources
    manifest_p = app_dir / "src" / "main" / "AndroidManifest.xml"
    manifest = _read(manifest_p)
    res = app_dir / "src" / "main" / "res"
    if not manifest:
        actions.append(Action("warn", "The app module has no src/main/AndroidManifest.xml."))
        return actions
    refs = {(t, n) for t, n in re.findall(r"@(mipmap|drawable|xml|style|string|color)/([A-Za-z0-9_.]+)", manifest)}
    missing_icons, missing_xml, missing_styles, missing_strings, unresolved = [], [], [], [], []
    for rtype, name in sorted(refs):
        if _res_exists(res, rtype, name):
            continue
        if rtype == "mipmap" and name.startswith("ic_launcher"):
            missing_icons.append(name)
        elif rtype == "xml" and name in ("backup_rules", "data_extraction_rules"):
            missing_xml.append(name)
        elif rtype == "style" and name.startswith("Theme.") and not _LIB_STYLE.match(name):
            missing_styles.append(name)
        elif rtype == "string":
            missing_strings.append(name)
        else:
            unresolved.append(f"@{rtype}/{name}")

    label = _humanize(app_dir.name)
    m = re.search(r'android:label\s*=\s*"([^"@]+)"', manifest)
    if m:
        label = m.group(1)

    if missing_icons:
        actions.append(Action("fix", "Missing launcher icon(s) " + ", ".join(missing_icons) + ": generating placeholder icons.",
                              lambda: icons.write_launcher_icons(res, missing_icons, label, "#1F2937")))
    if missing_xml:
        def write_xml():
            (res / "xml").mkdir(parents=True, exist_ok=True)
            if "backup_rules" in missing_xml:
                (res / "xml" / "backup_rules.xml").write_text(
                    '<?xml version="1.0" encoding="utf-8"?>\n<full-backup-content>\n'
                    '    <include domain="sharedpref" path="."/>\n</full-backup-content>\n', encoding="utf-8")
            if "data_extraction_rules" in missing_xml:
                (res / "xml" / "data_extraction_rules.xml").write_text(
                    '<?xml version="1.0" encoding="utf-8"?>\n<data-extraction-rules>\n'
                    '    <cloud-backup><include domain="sharedpref" path="."/></cloud-backup>\n'
                    '    <device-transfer><include domain="sharedpref" path="."/></device-transfer>\n'
                    '</data-extraction-rules>\n', encoding="utf-8")
        actions.append(Action("fix", "Missing backup XML(s) " + ", ".join(missing_xml) + ": generating defaults.", write_xml))
    if missing_styles:
        def write_styles():
            (res / "values").mkdir(parents=True, exist_ok=True)
            body = "".join(f'    <style name="{s}" parent="android:Theme.Material.NoActionBar" />\n' for s in missing_styles)
            (res / "values" / "z2a_generated_themes.xml").write_text(
                '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n' + body + '</resources>\n', encoding="utf-8")
        actions.append(Action("fix", "Missing theme(s) " + ", ".join(missing_styles) + ": generating a minimal Material theme (dark, no action bar).", write_styles))
    if missing_strings:
        def write_strings():
            (res / "values").mkdir(parents=True, exist_ok=True)
            body = "".join(f'    <string name="{s}">{_humanize(s)}</string>\n' for s in missing_strings)
            (res / "values" / "z2a_generated_strings.xml").write_text(
                '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n' + body + '</resources>\n', encoding="utf-8")
        actions.append(Action("fix", "Missing manifest string(s) " + ", ".join(missing_strings) + ": generating placeholders.", write_strings))
    if unresolved:
        actions.append(Action("warn", "Manifest references resources that are not in the ZIP and cannot be guessed: " + ", ".join(unresolved) + ". The build will probably fail."))

    # ---- source references to resources that do not exist (report only)
    src_main = app_dir / "src" / "main"
    miss_src: set[str] = set()
    rx = re.compile(r"(?<![\w.])R\.(string|drawable|mipmap|color|raw|dimen|layout|xml)\.(\w+)")
    for f in list(src_main.rglob("*.kt")) + list(src_main.rglob("*.java")):
        for rtype, name in rx.findall(_read(f, 300_000)):
            if not _res_exists(res, rtype, name):
                miss_src.add(f"R.{rtype}.{name}")
    if miss_src:
        actions.append(Action("warn", "Source code uses resources that are not in the ZIP: " + ", ".join(sorted(miss_src)[:8]) + ". The build will fail unless the res/ folder is included."))
    return actions


def apply(actions: list[Action]) -> list[str]:
    done = []
    for a in actions:
        if a.apply:
            a.apply()
            done.append(a.message)
    return done
