"""Runtime configuration, read from ZIP2APK_* environment variables."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

MB = 1024 * 1024
_BASE = Path(__file__).resolve().parent
_ROOT = _BASE.parent.parent


def _env(name: str, default: str) -> str:
    return os.environ.get(f"ZIP2APK_{name}", default)


def _int(name: str, default: int) -> int:
    return int(_env(name, str(default)))


def _bool(name: str, default: bool) -> bool:
    return _env(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    data_dir: Path
    frontend_dir: Path
    template_dir: Path
    # upload / zip limits
    max_upload_bytes: int
    max_unzipped_bytes: int
    max_file_bytes: int
    max_entries: int
    max_ratio: int
    max_icon_bytes: int
    # job handling
    build_timeout: int
    max_log_bytes: int
    job_ttl: int
    concurrency: int
    max_queued: int
    max_active_per_client: int
    trust_proxy_header: bool
    api_token: str
    # runner
    runner: str  # "docker" (default, sandboxed) or "local" (dev / trusted only)
    docker_bin: str
    docker_image: str
    docker_network: str
    docker_memory: str
    docker_cpus: str
    docker_pids: int
    allow_unsafe_local_android: bool
    # local runner toolchain (inside the docker image these are fixed)
    android_home: str
    gradle_home: str
    bundled_gradle: str
    wrapper_template: str
    build_script: str
    debug_keystore: str


def load() -> Settings:
    return Settings(
        data_dir=Path(_env("DATA_DIR", str(_ROOT / "data"))).resolve(),
        frontend_dir=Path(_env("FRONTEND_DIR", str(_ROOT / "frontend"))).resolve(),
        template_dir=_BASE / "templates" / "webview",
        max_upload_bytes=_int("MAX_UPLOAD_MB", 100) * MB,
        max_unzipped_bytes=_int("MAX_UNZIPPED_MB", 500) * MB,
        max_file_bytes=_int("MAX_FILE_MB", 100) * MB,
        max_entries=_int("MAX_ENTRIES", 20000),
        max_ratio=_int("MAX_COMPRESSION_RATIO", 200),
        max_icon_bytes=_int("MAX_ICON_MB", 2) * MB,
        build_timeout=_int("BUILD_TIMEOUT_SEC", 1200),
        max_log_bytes=_int("MAX_LOG_MB", 8) * MB,
        job_ttl=_int("JOB_TTL_SEC", 3600),
        concurrency=_int("CONCURRENCY", 1),
        max_queued=_int("MAX_QUEUED", 20),
        max_active_per_client=_int("MAX_ACTIVE_PER_CLIENT", 2),
        trust_proxy_header=_bool("TRUST_PROXY_HEADER", False),
        api_token=_env("API_TOKEN", ""),
        runner=_env("RUNNER", "docker"),
        docker_bin=_env("DOCKER_BIN", "docker"),
        docker_image=_env("DOCKER_IMAGE", "zip2apk-builder:latest"),
        docker_network=_env("DOCKER_NETWORK", "bridge"),
        docker_memory=_env("DOCKER_MEMORY", "6g"),
        docker_cpus=_env("DOCKER_CPUS", "2"),
        docker_pids=_int("DOCKER_PIDS", 1024),
        allow_unsafe_local_android=_bool("ALLOW_UNSAFE_LOCAL_ANDROID", False),
        android_home=_env("ANDROID_HOME", os.environ.get("ANDROID_HOME", "")),
        gradle_home=_env("GRADLE_HOME", os.environ.get("GRADLE_HOME", "")),
        bundled_gradle=_env("BUNDLED_GRADLE", "8.9"),
        wrapper_template=_env("WRAPPER_TEMPLATE", ""),
        build_script=_env("BUILD_SCRIPT", str(_ROOT / "builder" / "build.sh")),
        debug_keystore=_env("DEBUG_KEYSTORE", ""),
    )
