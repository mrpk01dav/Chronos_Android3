plugins {
    id("com.android.application")
}

// Per-build values come from gradle.properties (written by the converter), so this file is static
// and the dependency cache baked into the builder image stays valid.
fun prop(name: String) = providers.gradleProperty(name).get()

android {
    namespace = "app.zip2apk.wrapper"
    compileSdk = 35
    buildToolsVersion = "35.0.0"

    defaultConfig {
        applicationId = prop("z2a.applicationId")
        minSdk = 24
        targetSdk = 34
        versionCode = prop("z2a.versionCode").toInt()
        versionName = prop("z2a.versionName")
    }

    // The default pattern drops folders starting with "_" (e.g. Next.js "_next", Astro "_astro").
    // Same as the default, minus "<dir>_*".
    androidResources {
        ignoreAssetsPattern = "!.svn:!.git:!.ds_store:!*.scc:.*:!CVS:!thumbs.db:!picasa.ini:!*~"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
