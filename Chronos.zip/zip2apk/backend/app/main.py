"""FastAPI application: REST API + static frontend.

Upload is a raw-body PUT (no multipart) so the size limit is enforced while streaming.
"""
from __future__ import annotations

import asyncio
import hmac
import time
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
from starlette.concurrency import run_in_threadpool

from . import builder, config, webwrap
from .icons import valid_hex
from .jobs import JobError, JobManager

settings = config.load()
manager = JobManager(settings)
_caps_cache: tuple[float, dict] = (0.0, {})


@asynccontextmanager
async def lifespan(_: FastAPI):
    await manager.start()
    yield
    await manager.stop()


app = FastAPI(title="ZIP to APK Converter", lifespan=lifespan, docs_url="/api/docs", openapi_url="/api/openapi.json")


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "no-referrer")
    if not request.url.path.startswith("/api/docs"):
        resp.headers.setdefault("Content-Security-Policy",
                                "default-src 'self'; img-src 'self' data: blob:; style-src 'self'; script-src 'self'; frame-ancestors 'none'")
    return resp


@app.exception_handler(JobError)
async def job_error_handler(_: Request, exc: JobError):
    return JSONResponse({"error": {"code": exc.code, "message": exc.message}}, status_code=exc.status)


def client_id(request: Request) -> str:
    if settings.trust_proxy_header:
        fwd = request.headers.get("x-forwarded-for", "")
        if fwd:
            return fwd.split(",")[-1].strip()  # last hop = the address our trusted proxy saw
    return request.client.host if request.client else "unknown"


def require_auth(request: Request):
    if not settings.api_token:
        return
    got = request.headers.get("authorization", "")
    if not hmac.compare_digest(got, f"Bearer {settings.api_token}"):
        raise HTTPException(status_code=401, detail="Missing or invalid API token.")


async def capabilities() -> dict:
    global _caps_cache
    if time.time() - _caps_cache[0] > 30:
        _caps_cache = (time.time(), await run_in_threadpool(builder.readiness, settings))
    return _caps_cache[1]


async def read_body(request: Request, limit: int) -> bytes:
    declared = request.headers.get("content-length")
    if declared and declared.isdigit() and int(declared) > limit:
        raise JobError("too_large", f"File exceeds the {limit // (1024 * 1024)} MB limit.", 413)
    buf = bytearray()
    async for chunk in request.stream():
        buf += chunk
        if len(buf) > limit:
            raise JobError("too_large", f"File exceeds the {limit // (1024 * 1024)} MB limit.", 413)
    return bytes(buf)


# ------------------------------------------------------------------ API -----
@app.get("/api/health")
async def health():
    caps = await capabilities()
    return {"ok": True, **caps, "limits": {
        "max_upload_mb": settings.max_upload_bytes // (1024 * 1024),
        "build_timeout_min": settings.build_timeout // 60,
        "auth_required": bool(settings.api_token)}}


@app.put("/api/uploads", dependencies=[Depends(require_auth)])
async def upload(request: Request):
    job = manager.create(client_id(request))
    try:
        declared = request.headers.get("content-length")
        if declared and declared.isdigit() and int(declared) > settings.max_upload_bytes:
            raise JobError("too_large", f"File exceeds the {settings.max_upload_bytes // (1024 * 1024)} MB limit.", 413)
        size = 0
        with open(job.dir / "upload.zip", "wb") as f:
            async for chunk in request.stream():
                size += len(chunk)
                if size > settings.max_upload_bytes:
                    raise JobError("too_large", f"File exceeds the {settings.max_upload_bytes // (1024 * 1024)} MB limit.", 413)
                f.write(chunk)
        if size == 0:
            raise JobError("empty", "The upload was empty.", 400)
        job.filename = (request.headers.get("x-filename") or "upload.zip")[:120]
        await run_in_threadpool(manager.inspect, job)
    except JobError:
        manager.delete(job.id)
        raise
    except Exception:
        manager.delete(job.id)
        raise
    return manager.view(job)


class BuildOptions(BaseModel):
    app_name: str = Field("My Web App", min_length=1, max_length=50)
    package_name: str = Field("com.zip2apk.app", max_length=100)
    version_name: str = Field("1.0.0", max_length=20)
    version_code: int = Field(1, ge=1, le=2_100_000_000)
    internet: bool = True
    orientation: Literal["auto", "portrait", "landscape"] = "auto"
    theme_color: str = "#3B5BDB"
    icon_mode: Literal["auto", "favicon", "upload"] = "auto"
    spa_fallback: bool = True

    @field_validator("theme_color")
    @classmethod
    def _color(cls, v: str) -> str:
        if not valid_hex(v):
            raise ValueError("theme_color must be #RRGGBB")
        return v

    @field_validator("package_name")
    @classmethod
    def _pkg(cls, v: str) -> str:
        try:
            return webwrap.validate_package(v)
        except webwrap.OptionError as exc:
            raise ValueError(str(exc))


@app.put("/api/jobs/{job_id}/icon", dependencies=[Depends(require_auth)])
async def set_icon(job_id: str, request: Request):
    job = manager.get(job_id)
    data = await read_body(request, settings.max_icon_bytes)
    await run_in_threadpool(manager.set_icon, job, data)
    return {"ok": True}


@app.post("/api/jobs/{job_id}/build", dependencies=[Depends(require_auth)])
async def start_build(job_id: str, opts: BuildOptions):
    job = manager.get(job_id)
    caps = await capabilities()
    manager.enqueue(job, opts.model_dump(), caps)
    return manager.view(job)


@app.get("/api/jobs/{job_id}", dependencies=[Depends(require_auth)])
async def job_status(job_id: str, since: int = 0):
    return manager.view(manager.get(job_id), since)


@app.get("/api/jobs/{job_id}/apk", dependencies=[Depends(require_auth)])
async def download_apk(job_id: str):
    job = manager.get(job_id)
    if job.status != "succeeded" or not job.apk or not job.apk.is_file():
        raise JobError("no_apk", "No APK is available for this job.", 404)
    job.touch()
    return FileResponse(job.apk, media_type="application/vnd.android.package-archive", filename=job.download_name)


@app.delete("/api/jobs/{job_id}", dependencies=[Depends(require_auth)])
async def delete_job(job_id: str):
    manager.get(job_id)
    manager.delete(job_id)
    return {"ok": True}


# -------------------------------------------------------------- frontend ----
app.mount("/", StaticFiles(directory=str(settings.frontend_dir), html=True), name="frontend")
