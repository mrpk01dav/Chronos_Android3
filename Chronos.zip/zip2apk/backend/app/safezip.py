"""Hostile-ZIP-safe validation and extraction.

Never uses ZipFile.extractall(). Every member is checked first, then streamed to disk with
byte counters that do not trust the sizes declared in the archive header.
"""
from __future__ import annotations

import os
import re
import stat
import zipfile
import zlib
from dataclasses import dataclass, field
from pathlib import Path


class ZipRejected(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass(frozen=True)
class Limits:
    max_entries: int
    max_unzipped_bytes: int
    max_file_bytes: int
    max_ratio: int


@dataclass
class ExtractReport:
    files: int = 0
    dirs: int = 0
    bytes: int = 0
    skipped: list[str] = field(default_factory=list)


_DRIVE = re.compile(r"^[A-Za-z]:")
_JUNK_DIRS = {"__MACOSX"}
_JUNK_FILES = {".DS_Store", "Thumbs.db"}
_MB = 1024 * 1024


def normalize_member(name: str) -> str | None:
    """Return a safe relative POSIX path, None for ignorable junk, or raise ZipRejected."""
    if "\x00" in name:
        raise ZipRejected("unsafe_path", "ZIP contains an entry with a NUL byte in its name.")
    n = name.replace("\\", "/")
    if n.startswith("/") or _DRIVE.match(n):
        raise ZipRejected("unsafe_path", f"ZIP contains an absolute path ({name[:80]!r}).")
    parts = [p for p in n.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        raise ZipRejected("unsafe_path", f"ZIP contains a path-traversal entry ({name[:80]!r}).")
    if not parts:
        return None
    if parts[0] in _JUNK_DIRS or parts[-1] in _JUNK_FILES:
        return None
    if len(parts) > 40 or len(n) > 260:
        raise ZipRejected("unsafe_path", "ZIP contains an excessively deep or long path.")
    return "/".join(parts)


def _inside(base: Path, p: Path) -> bool:
    try:
        p.relative_to(base)
        return True
    except ValueError:
        return False


def safe_extract(zip_path: Path, dest: Path, limits: Limits) -> ExtractReport:
    if not zipfile.is_zipfile(zip_path):
        raise ZipRejected("not_zip", "The uploaded file is not a valid ZIP archive.")
    dest.mkdir(parents=True, exist_ok=True)
    base = dest.resolve()
    report = ExtractReport()
    try:
        with zipfile.ZipFile(zip_path) as zf:
            infos = zf.infolist()
            if len(infos) > limits.max_entries:
                raise ZipRejected("too_many_entries", f"ZIP has more than {limits.max_entries} entries.")

            plan: list[tuple[zipfile.ZipInfo, str]] = []
            declared = 0
            for info in infos:
                rel = normalize_member(info.filename)
                if rel is None:
                    report.skipped.append(info.filename)
                    continue
                mode = info.external_attr >> 16
                fmt = stat.S_IFMT(mode)
                if fmt == stat.S_IFLNK:
                    raise ZipRejected("symlink", f"ZIP contains a symbolic link ({rel!r}); these are not allowed.")
                if fmt not in (0, stat.S_IFREG, stat.S_IFDIR):
                    raise ZipRejected("special_file", f"ZIP contains a special file ({rel!r}).")
                if info.flag_bits & 0x1:
                    raise ZipRejected("encrypted", "Password-protected ZIP files are not supported.")
                if not info.is_dir():
                    if info.file_size > limits.max_file_bytes:
                        raise ZipRejected("file_too_large", f"{rel!r} exceeds the per-file limit of {limits.max_file_bytes // _MB} MB.")
                    declared += info.file_size
                    if declared > limits.max_unzipped_bytes:
                        raise ZipRejected("unzipped_too_large", f"ZIP expands beyond {limits.max_unzipped_bytes // _MB} MB.")
                    if info.file_size > _MB and info.compress_size > 0 and info.file_size / info.compress_size > limits.max_ratio:
                        raise ZipRejected("zip_bomb", f"{rel!r} has a suspicious compression ratio (possible zip bomb).")
                plan.append((info, rel))

            total = 0
            for info, rel in plan:
                target = Path(os.path.normpath(base / rel))
                if not _inside(base, target):
                    raise ZipRejected("unsafe_path", f"Entry escapes the extraction directory ({rel!r}).")
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    report.dirs += 1
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                if not _inside(base, target.parent.resolve()):
                    raise ZipRejected("unsafe_path", f"Entry escapes the extraction directory ({rel!r}).")
                written = 0
                try:
                    with zf.open(info) as src, open(target, "xb") as out:
                        while chunk := src.read(1 << 16):
                            written += len(chunk)
                            total += len(chunk)
                            if written > limits.max_file_bytes or total > limits.max_unzipped_bytes:
                                raise ZipRejected("unzipped_too_large", "ZIP expands beyond the allowed size.")
                            out.write(chunk)
                except FileExistsError:
                    raise ZipRejected("duplicate_entry", f"ZIP contains a duplicate entry ({rel!r}).")
                os.chmod(target, 0o644)
                report.files += 1
                report.bytes += written
    except ZipRejected:
        raise
    except (zipfile.BadZipFile, zlib.error, EOFError, NotImplementedError, RuntimeError, OSError) as exc:
        raise ZipRejected("bad_zip", f"The ZIP archive is corrupt or unsupported ({type(exc).__name__}).")
    return report
