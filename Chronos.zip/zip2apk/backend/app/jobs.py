"""Job lifecycle: upload -> inspect -> (queued) -> build -> cleanup."""
from __future__ import annotations

import asyncio
import logging
import re
import secrets
import shutil
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Awaitable, Callable

from . import androidfix, builder, detector, icons, safezip, webwrap
from .config import Settings

log = logging.getLogger("zip2apk")
ID_RE = re.compile(r"^[A-Za-z0-9_-]{16,32}$")
ACTIVE = {"queued", "running"}


class JobError(Exception):
    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


@dataclass
class Job:
    id: str
    dir: Path
    client: str
    created: float = field(default_factory=time.time)
    updated: float = field(default_factory=time.time)
    status: str = "uploading"  # uploading|inspected|queued|running|succeeded|failed
    stage: str = ""
    progress: int = 0
    current_task: str = ""
    detection: detector.Detection | None = None
    filename: str = ""
    options: dict = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)
    lines: list[str] = field(default_factory=list)
    tail: deque = field(default_factory=lambda: deque(maxlen=300))
    log_bytes: int = 0
    log_truncated: bool = False
    error: dict | None = None
    apk: Path | None = None
    apk_info: dict | None = None
    download_name: str = "app-debug.apk"

    def touch(self):
        self.updated = time.time()

    def add_log(self, line: str, cap: int):
        self.tail.append(line)
        if self.log_bytes < cap:
            self.lines.append(line[:2000])
            self.log_bytes += len(line) + 1
        elif not self.log_truncated:
            self.log_truncated = True
            self.lines.append("[log truncated: size limit reached; the final lines are used for diagnostics]")
        self.touch()


def _slug(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-.")[:40] or "app"


class JobManager:
    def __init__(self, settings: Settings, runner=builder.run_build):
        self.s = settings
        self.run = runner
        self.jobs: dict[str, Job] = {}
        self.queue: asyncio.Queue[str] = asyncio.Queue()
        self._tasks: list[asyncio.Task] = []
        (settings.data_dir / "jobs").mkdir(parents=True, exist_ok=True)

    # ---- lifecycle
    async def start(self):
        self._sweep_orphans()
        for _ in range(max(1, self.s.concurrency)):
            self._tasks.append(asyncio.create_task(self._worker()))
        self._tasks.append(asyncio.create_task(self._janitor()))

    async def stop(self):
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)

    def _sweep_orphans(self):
        for d in (self.s.data_dir / "jobs").iterdir():
            shutil.rmtree(d, ignore_errors=True)  # server restarted: in-memory jobs are gone

    async def _janitor(self):
        while True:
            await asyncio.sleep(60)
            now = time.time()
            for job in list(self.jobs.values()):
                if job.status not in ACTIVE and now - job.updated > self.s.job_ttl:
                    self.delete(job.id)

    # ---- access
    def get(self, job_id: str) -> Job:
        if not ID_RE.match(job_id or "") or job_id not in self.jobs:
            raise JobError("not_found", "Job not found or expired.", 404)
        return self.jobs[job_id]

    def delete(self, job_id: str):
        job = self.jobs.get(job_id)
        if job and job.status in ACTIVE:
            raise JobError("busy", "The job is still running.", 409)
        self.jobs.pop(job_id, None)
        shutil.rmtree(self.s.data_dir / "jobs" / job_id, ignore_errors=True)

    # ---- step 1: upload + inspect
    def create(self, client: str) -> Job:
        active = sum(1 for j in self.jobs.values() if j.client == client and j.status != "failed" and j.status != "succeeded")
        if active >= self.s.max_active_per_client + 3:
            raise JobError("too_many", "Too many open uploads from your address; finish or wait for expiry.", 429)
        jid = secrets.token_urlsafe(18)
        d = self.s.data_dir / "jobs" / jid
        d.mkdir(parents=True, mode=0o700)
        job = Job(jid, d, client)
        self.jobs[jid] = job
        return job

    def inspect(self, job: Job) -> None:
        """Blocking: validate + extract + detect. Call in a worker thread."""
        zpath = job.dir / "upload.zip"
        src = job.dir / "src"
        lim = safezip.Limits(self.s.max_entries, self.s.max_unzipped_bytes, self.s.max_file_bytes, self.s.max_ratio)
        try:
            safezip.safe_extract(zpath, src, lim)
        except safezip.ZipRejected as exc:
            self.delete(job.id)
            raise JobError(exc.code, exc.message, 422)
        finally:
            zpath.unlink(missing_ok=True)
        det = detector.detect(src, self.s.bundled_gradle)
        job.detection = det
        if det.kind == "android":
            app_dir = Path(det.info["_app_dir"]) if det.info.get("_app_dir") else None
            plan = androidfix.analyze(det.root, app_dir, det.info["gradle"], det.info["has_wrapper"])
            job.notes = []
            det.info["plan"] = [{"kind": a.kind, "message": a.message} for a in plan]
        job.status = "inspected"
        job.touch()

    # ---- step 2: build request
    def set_icon(self, job: Job, data: bytes):
        if job.status != "inspected":
            raise JobError("bad_state", "Icon can only be set before the build starts.", 409)
        p = job.dir / "icon.bin"
        p.write_bytes(data)
        try:
            icons.load_source(p)
        except icons.IconError as exc:
            p.unlink(missing_ok=True)
            raise JobError("bad_icon", str(exc), 422)

    def enqueue(self, job: Job, options: dict, caps: dict) -> None:
        if job.status != "inspected" or not job.detection or not job.detection.buildable:
            raise JobError("bad_state", "This upload cannot be built.", 409)
        kind = job.detection.kind
        if not caps["web_builds" if kind == "web" else "android_builds"]:
            raise JobError("builder_unavailable", "This server cannot build that project type: " + " ".join(caps["reasons"]), 503)
        if self.queue.qsize() >= self.s.max_queued:
            raise JobError("queue_full", "The build queue is full. Try again in a few minutes.", 429)
        mine = sum(1 for j in self.jobs.values() if j.client == job.client and j.status in ACTIVE)
        if mine >= self.s.max_active_per_client:
            raise JobError("too_many", "You already have builds in progress.", 429)
        if kind == "web":  # validate early so the user gets field errors before queueing
            try:
                webwrap.validate_package(options["package_name"])
            except webwrap.OptionError as exc:
                raise JobError("bad_options", str(exc), 422)
        job.options = options
        job.status = "queued"
        job.stage, job.progress = "queued", 5
        job.touch()
        self.queue.put_nowait(job.id)

    # ---- worker
    async def _worker(self):
        while True:
            jid = await self.queue.get()
            job = self.jobs.get(jid)
            if job is None:
                continue
            try:
                await self._build(job)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # never let one job kill the worker
                log.exception("job %s crashed", jid)
                self._fail(job, "internal_error", f"Internal error: {type(exc).__name__}", [])
            finally:
                for sub in ("src", "project", "scratch"):
                    shutil.rmtree(job.dir / sub, ignore_errors=True)

    def _fail(self, job: Job, code: str, message: str, hints: list[str]):
        job.status, job.stage = "failed", "failed"
        job.error = {"code": code, "message": message, "hints": hints}
        job.add_log(f"ERROR [{code}]: {message}", self.s.max_log_bytes)

    def _line(self, job: Job, line: str):
        job.add_log(line, self.s.max_log_bytes)
        stage, pct, task = builder.parse_line(line)
        if stage:
            job.stage = stage
        if pct and pct > job.progress:
            job.progress = pct
        if task:
            job.current_task = task

    async def _build(self, job: Job):
        det = job.detection
        assert det is not None
        job.status, job.stage, job.progress = "running", "prepare", 8
        log_ = lambda m: job.add_log(m, self.s.max_log_bytes)  # noqa: E731
        out_dir = job.dir / "out"
        out_dir.mkdir(exist_ok=True)
        out_dir.chmod(0o755)

        if det.kind == "web":
            o = job.options
            icon_path = job.dir / "icon.bin"
            opts = webwrap.WebOptions(
                app_name=o["app_name"], package_name=o["package_name"], version_name=o["version_name"],
                version_code=o["version_code"], internet=o["internet"], orientation=o["orientation"],
                theme_color=o["theme_color"], icon_mode=o["icon_mode"],
                icon_path=icon_path if icon_path.is_file() else None, spa_fallback=o["spa_fallback"])
            project = job.dir / "project"
            log_("Generating Android WebView project from website files…")
            try:
                notes = await asyncio.to_thread(webwrap.generate_project, det.root, det.info["entry"], project, opts, self.s.template_dir)
            except (webwrap.OptionError, icons.IconError) as exc:
                return self._fail(job, "bad_options", str(exc), [])
            for n in notes:
                log_("• " + n)
            job.notes = notes
            gradle_ver, task, trusted = self.s.bundled_gradle, "assembleDebug", True
            job.download_name = f"{_slug(opts.app_name)}-debug.apk"
        else:
            project = det.root
            app_dir = Path(det.info["_app_dir"]) if det.info.get("_app_dir") else None
            plan = androidfix.analyze(project, app_dir, det.info["gradle"], det.info["has_wrapper"])
            for a in plan:
                log_(f"[{a.kind}] {a.message}")
            applied = androidfix.apply(plan)
            job.notes = applied
            mod = det.info.get("app_module")
            gradle_ver = det.info["gradle"]
            task = f"{mod}:assembleDebug" if mod else "assembleDebug"
            trusted = False
            job.download_name = f"{_slug(project.name if project.name != 'src' else (mod or 'app').strip(':'))}-debug.apk"
        self._open_perms(project)

        spec = builder.BuildSpec(job.id, project.resolve(), out_dir.resolve(), gradle_ver, task, trusted)
        result = await self.run(self.s, spec, lambda l: self._line(job, l))
        if not result.ok:
            return self._fail(job, result.error_code, result.message, result.hints)
        try:
            info = await asyncio.to_thread(builder.validate_apk, result.apk)
        except Exception as exc:
            return self._fail(job, "invalid_apk", str(exc), [])
        job.apk, job.apk_info = result.apk, info
        job.status, job.stage, job.progress = "succeeded", "done", 100
        log_(f"BUILD SUCCESSFUL: {result.apk.name} ({info['size'] / 1e6:.1f} MB, sha256 {info['sha256'][:16]}…)")

    @staticmethod
    def _open_perms(project: Path):
        """Container runs as the backend uid, but make sure the tree is writable for it."""
        for p in [project, *project.rglob("*")]:
            try:
                p.chmod(0o755 if p.is_dir() else 0o644)
            except OSError:
                pass

    # ---- API view
    def view(self, job: Job, since: int = 0) -> dict:
        since = max(0, min(since, len(job.lines)))
        d = {
            "id": job.id, "status": job.status, "stage": job.stage, "progress": job.progress,
            "current_task": job.current_task, "filename": job.filename,
            "detection": job.detection.public(job.dir / "src") if job.detection else None,
            "notes": job.notes, "log": job.lines[since:], "next": len(job.lines), "error": job.error,
            "expires_in": max(0, int(self.s.job_ttl - (time.time() - job.updated))) if job.status not in ACTIVE else None,
        }
        if job.status == "queued":
            d["queue_position"] = list(self.queue._queue).index(job.id) + 1 if job.id in self.queue._queue else 0  # type: ignore[attr-defined]
        if job.apk_info:
            d["apk"] = {**job.apk_info, "name": job.download_name}
        return d
