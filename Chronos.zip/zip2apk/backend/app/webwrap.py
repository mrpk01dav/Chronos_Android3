"""Generate a complete Android (WebView wrapper) Gradle project from website files."""
from __future__ import annotations

import os
import re
import shutil
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote
from xml.sax.saxutils import escape

from . import icons

_JAVA_KEYWORDS = {
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue",
    "default", "do", "double", "else", "enum", "extends", "final", "finally", "float", "for", "goto", "if",
    "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "package", "private",
    "protected", "public", "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
    "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false", "null", "_",
}
_PKG = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$")
_SKIP_DIRS = {".git", "node_modules", "__MACOSX", ".svn"}
_ORIENT = {"auto": "unspecified", "portrait": "portrait", "landscape": "landscape"}


class OptionError(ValueError):
    pass


def validate_package(pkg: str) -> str:
    if not _PKG.match(pkg or "") or len(pkg) > 100:
        raise OptionError("Package name must look like com.example.myapp (lowercase letters, digits, underscores; at least two segments).")
    bad = [p for p in pkg.split(".") if p in _JAVA_KEYWORDS]
    if bad:
        raise OptionError(f"Package segment '{bad[0]}' is a reserved Java keyword.")
    return pkg


def default_package(app_name: str) -> str:
    slug = re.sub(r"[^a-z0-9]", "", app_name.lower()) or "app"
    if not slug[0].isalpha():
        slug = "app" + slug
    if slug in _JAVA_KEYWORDS:
        slug += "app"
    return f"com.zip2apk.{slug[:40]}"


def android_string(value: str) -> str:
    """Escape for a <string> resource body."""
    v = escape(value).replace("'", "\\'").replace('"', '\\"').replace("\n", "\\n")
    if v.startswith(("@", "?")):
        v = "\\" + v
    return v


@dataclass
class WebOptions:
    app_name: str
    package_name: str
    version_name: str = "1.0.0"
    version_code: int = 1
    internet: bool = True
    orientation: str = "auto"
    theme_color: str = "#3B5BDB"
    icon_mode: str = "auto"  # auto | favicon | upload
    icon_path: Path | None = None
    spa_fallback: bool = True


def _luma(hexcolor: str) -> float:
    r, g, b = (int(hexcolor[i:i + 2], 16) for i in (1, 3, 5))
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255


def copy_site(src: Path, dst: Path) -> tuple[int, int]:
    """Copy website files, skipping symlinks, VCS/node folders. Returns (files, bytes)."""
    n = size = 0
    src = src.resolve()
    for d, dirs, files in os.walk(src, followlinks=False):
        dirs[:] = [x for x in dirs if x not in _SKIP_DIRS and not os.path.islink(os.path.join(d, x))]
        rel = Path(d).relative_to(src)
        (dst / rel).mkdir(parents=True, exist_ok=True)
        for f in files:
            p = Path(d) / f
            if p.is_symlink() or not p.is_file() or f in {".DS_Store", "Thumbs.db"}:
                continue
            shutil.copyfile(p, dst / rel / f)
            n += 1
            size += p.stat().st_size
    return n, size


def generate_project(site_root: Path, entry: str, out_dir: Path, opts: WebOptions, template_dir: Path) -> list[str]:
    """Write the Gradle project into out_dir. Returns human-readable notes."""
    notes: list[str] = []
    validate_package(opts.package_name)
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", opts.theme_color):
        raise OptionError("Theme colour must be a #RRGGBB value.")
    if opts.orientation not in _ORIENT:
        raise OptionError("Orientation must be auto, portrait or landscape.")
    if not re.fullmatch(r"\d{1,3}(\.\d{1,3}){0,3}", opts.version_name):
        raise OptionError("Version name must look like 1.0.0.")
    if not 1 <= opts.version_code <= 2_100_000_000:
        raise OptionError("Version code is out of range.")
    name = opts.app_name.strip()
    if not name or len(name) > 50:
        raise OptionError("App name must be 1-50 characters.")

    if out_dir.exists():
        shutil.rmtree(out_dir)
    shutil.copytree(template_dir, out_dir)
    main = out_dir / "app" / "src" / "main"
    res = main / "res"
    (res / "values").mkdir(parents=True, exist_ok=True)

    # gradle.properties (all per-build values live here)
    (out_dir / "gradle.properties").write_text(
        "org.gradle.jvmargs=-Xmx2g -Dfile.encoding=UTF-8\n"
        "android.useAndroidX=true\n"
        "android.nonTransitiveRClass=true\n"
        f"z2a.applicationId={opts.package_name}\n"
        f"z2a.versionCode={opts.version_code}\n"
        f"z2a.versionName={opts.version_name}\n", encoding="utf-8")

    # manifest
    manifest = (main / "AndroidManifest.xml").read_text(encoding="utf-8")
    internet = '    <uses-permission android:name="android.permission.INTERNET" />' if opts.internet else ""
    manifest = manifest.replace("{{INTERNET_PERMISSION}}", internet).replace("{{ORIENTATION}}", _ORIENT[opts.orientation])
    (main / "AndroidManifest.xml").write_text(manifest, encoding="utf-8")

    # resources
    start = "https://appassets.androidplatform.net/" + "/".join(quote(p) for p in entry.split("/"))
    (res / "values" / "strings.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
        f'    <string name="app_name" formatted="false">{android_string(name)}</string>\n'
        f'    <string name="start_url" formatted="false">{escape(start)}</string>\n'
        '</resources>\n', encoding="utf-8")
    (res / "values" / "config.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
        f'    <bool name="spa_fallback">{str(opts.spa_fallback).lower()}</bool>\n'
        f'    <color name="z2a_primary">{opts.theme_color}</color>\n'
        '</resources>\n', encoding="utf-8")
    light = "true" if _luma(opts.theme_color) > 0.6 else "false"
    (res / "values" / "themes.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
        '    <style name="AppTheme" parent="android:Theme.Material.Light.NoActionBar">\n'
        '        <item name="android:windowBackground">#FFFFFF</item>\n'
        '        <item name="android:statusBarColor">@color/z2a_primary</item>\n'
        f'        <item name="android:windowLightStatusBar">{light}</item>\n'
        '    </style>\n</resources>\n', encoding="utf-8")

    # icon
    source = None
    index_html = ""
    try:
        index_html = (site_root / entry).read_text(encoding="utf-8", errors="replace")[:200_000]
    except OSError:
        pass
    if opts.icon_mode == "upload" and opts.icon_path and opts.icon_path.is_file():
        source = icons.load_source(opts.icon_path)  # raises IconError -> reported to the user
        notes.append("Using your uploaded icon.")
    elif opts.icon_mode == "favicon":
        fav = icons.find_favicon(site_root, index_html)
        if fav:
            try:
                source = icons.load_source(fav)
                notes.append(f"Using the website icon ({fav.relative_to(site_root.resolve())}).")
            except icons.IconError:
                notes.append("The website's icon could not be read; generated an icon instead.")
        else:
            notes.append("No local favicon found in the website; generated an icon instead.")
    icons.write_launcher_icons(res, ("ic_launcher", "ic_launcher_round"), name, opts.theme_color, source)

    # website files -> assets/www
    www = main / "assets" / "www"
    www.mkdir(parents=True, exist_ok=True)
    files, size = copy_site(site_root, www)
    if not (www / entry).is_file():
        raise OptionError(f"Entry page '{entry}' was not copied; the website may only contain unsupported files.")
    notes.append(f"Bundled {files} website file(s), {size / 1024 / 1024:.1f} MB.")
    if not opts.internet:
        notes.append("Internet permission is OFF: external URLs (CDNs, APIs, fonts) will not load.")
    return notes
