"""Launcher icon generation with Pillow (PNG mipmaps for every density)."""
from __future__ import annotations

import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

DENSITIES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
_FONTS = ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
          "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
          "/Library/Fonts/Arial Bold.ttf", "C:/Windows/Fonts/arialbd.ttf")
MAX_SOURCE_DIM = 4096


class IconError(Exception):
    pass


def valid_hex(c: str) -> bool:
    return bool(re.fullmatch(r"#[0-9a-fA-F]{6}", c or ""))


def load_source(path: Path) -> Image.Image:
    """Open and sanitise a user-supplied image (PNG/JPEG/WEBP/ICO) as a square RGBA image."""
    try:
        with Image.open(path) as im:
            if im.format not in ("PNG", "JPEG", "WEBP", "ICO"):
                raise IconError("Icon must be PNG, JPEG, WEBP or ICO.")
            if im.width > MAX_SOURCE_DIM or im.height > MAX_SOURCE_DIM:
                raise IconError(f"Icon is larger than {MAX_SOURCE_DIM}px.")
            im = im.convert("RGBA")
    except IconError:
        raise
    except Exception as exc:  # corrupt / decompression bomb / unsupported
        raise IconError(f"Could not read the icon image ({type(exc).__name__}).")
    side = min(im.size)
    left, top = (im.width - side) // 2, (im.height - side) // 2
    return im.crop((left, top, left + side, top + side))


def _font(size: int):
    for f in _FONTS:
        if Path(f).is_file():
            return ImageFont.truetype(f, size)
    try:
        return ImageFont.load_default(size=size)
    except TypeError:  # Pillow < 10.1
        return ImageFont.load_default()


def _generated(label: str, color: str, px: int) -> Image.Image:
    im = Image.new("RGBA", (px, px), color)
    d = ImageDraw.Draw(im)
    ch = (label.strip()[:1] or "A").upper()
    d.text((px / 2, px / 2), ch, fill="white", font=_font(int(px * 0.55)), anchor="mm")
    return im


def _round(im: Image.Image) -> Image.Image:
    mask = Image.new("L", im.size, 0)
    ImageDraw.Draw(mask).ellipse((0, 0, im.width - 1, im.height - 1), fill=255)
    out = Image.new("RGBA", im.size, (0, 0, 0, 0))
    out.paste(im, (0, 0), mask)
    return out


def write_launcher_icons(res_dir: Path, names, label: str, color: str, source: Image.Image | None = None) -> list[str]:
    """Write ic_launcher*.png into res/mipmap-<density>/. Returns written relative paths."""
    written = []
    color = color if valid_hex(color) else "#3B5BDB"
    for name in names:
        for dens, px in DENSITIES.items():
            base = source.resize((px, px), Image.LANCZOS) if source is not None else _generated(label, color, px)
            im = _round(base) if name.endswith("_round") else base
            out = res_dir / f"mipmap-{dens}" / f"{name}.png"
            out.parent.mkdir(parents=True, exist_ok=True)
            im.save(out, "PNG", optimize=True)
            written.append(str(out.relative_to(res_dir)))
    return written


def find_favicon(webroot: Path, index_html: str) -> Path | None:
    """Locate a local PNG/ICO icon declared by the page or following common names."""
    cands: list[str] = []
    for m in re.finditer(r"<link[^>]+rel=[\"'][^\"']*icon[^\"']*[\"'][^>]*>", index_html, re.I):
        h = re.search(r"href=[\"']([^\"']+)[\"']", m.group(0), re.I)
        if h and not re.match(r"[a-z]+:", h.group(1), re.I):
            cands.append(h.group(1).split("?")[0].split("#")[0])
    cands += ["apple-touch-icon.png", "icon-512.png", "icon-192.png", "favicon.png", "favicon.ico",
              "icons/icon-512x512.png", "icons/icon-192x192.png", "assets/icon.png"]
    root = webroot.resolve()
    for c in cands:
        p = (root / c.lstrip("/")).resolve()
        if p.is_file() and p.suffix.lower() in (".png", ".ico", ".webp", ".jpg", ".jpeg"):
            try:
                p.relative_to(root)
            except ValueError:
                continue
            return p
    return None
