"""Inspect an extracted ZIP and decide what it is: Android Gradle project, website, or unsupported."""
from __future__ import annotations

import html
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

_SKIP = {"node_modules", ".git", "__MACOSX", ".gradle", ".idea"}
_WEB_PREFER = ("dist", "build", "www", "public", "out", "docs")

# Minimum Gradle version required by each Android Gradle Plugin line (major, minor) -> Gradle.
# Verify against https://developer.android.com/build/releases/gradle-plugin when adding new AGP lines.
AGP_TO_GRADLE = {
    (7, 3): "7.4", (7, 4): "7.5", (8, 0): "8.0", (8, 1): "8.0", (8, 2): "8.2", (8, 3): "8.4",
    (8, 4): "8.6", (8, 5): "8.7", (8, 6): "8.7", (8, 7): "8.9", (8, 8): "8.10.2", (8, 9): "8.11.1",
    (8, 10): "8.11.1", (8, 11): "8.13", (8, 12): "8.13", (8, 13): "8.13", (9, 0): "9.1.0",
}


@dataclass
class Detection:
    kind: str  # "android" | "web" | "unsupported" | "unknown"
    root: Path | None = None  # server-side only; never sent to clients
    reason: str = ""
    warnings: list[str] = field(default_factory=list)
    info: dict = field(default_factory=dict)

    @property
    def buildable(self) -> bool:
        return self.kind in ("android", "web")

    def public(self, base: Path) -> dict:
        rel = ""
        if self.root is not None:
            rel = os.path.relpath(self.root, base)
            rel = "" if rel == "." else rel
        return {"kind": self.kind, "root": rel or "(zip root)", "reason": self.reason,
                "warnings": self.warnings,
                "info": {k: v for k, v in self.info.items() if not k.startswith("_")}}


def _read(p: Path, limit: int = 300_000) -> str:
    try:
        return p.read_text(encoding="utf-8", errors="replace")[:limit] if p.is_file() else ""
    except OSError:
        return ""


def _walk(root: Path, max_depth: int, skip: set[str] = _SKIP):
    """Yield (dir, depth, dirnames, filenames) with pruning."""
    base_depth = len(root.parts)
    for d, dirs, files in os.walk(root, followlinks=False):
        depth = len(Path(d).parts) - base_depth
        dirs[:] = sorted(x for x in dirs if x not in skip)
        if depth >= max_depth:
            dirs[:] = []
        yield Path(d), depth, dirs, sorted(files)


def _vt(v: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", v)[:3])


def required_gradle(agp: str | None, wrapper: str | None, bundled: str) -> str:
    """Pick the Gradle version to build with."""
    need = None
    if agp:
        t = _vt(agp)
        if len(t) >= 2:
            need = AGP_TO_GRADLE.get((t[0], t[1]))
            if need is None and (t[0], t[1]) > max(AGP_TO_GRADLE):
                need = AGP_TO_GRADLE[max(AGP_TO_GRADLE)]
    if wrapper and need:
        return wrapper if _vt(wrapper) >= _vt(need) else need
    return wrapper or need or bundled


# ---------------------------------------------------------------- Android ----

def _find_settings(root: Path) -> Path | None:
    hits = []
    for d, depth, _, files in _walk(root, 2):
        if "settings.gradle.kts" in files or "settings.gradle" in files:
            hits.append((depth, str(d), d))
    return sorted(hits)[0][2] if hits else None


def _modules(project: Path) -> list[str]:
    txt = _read(project / "settings.gradle.kts") + "\n" + _read(project / "settings.gradle")
    mods: list[str] = []
    for m in re.finditer(r"include\s*\(?\s*((?:[\"'][^\"']+[\"']\s*,?\s*)+)\)?", txt):
        mods += re.findall(r"[\"']([^\"']+)[\"']", m.group(1))
    return mods


def _module_dir(project: Path, mod: str) -> Path | None:
    p = (project / mod.strip(":").replace(":", "/")).resolve()
    try:
        p.relative_to(project.resolve())
    except ValueError:
        return None
    return p if p.is_dir() else None


def _is_app_module(mdir: Path) -> bool:
    gradle = _read(mdir / "build.gradle.kts") + _read(mdir / "build.gradle")
    if re.search(r"com\.android\.library|android\.library|androidLibrary", gradle):
        return False
    if re.search(r"com\.android\.application|android\.application|androidApplication|android-application", gradle):
        return True
    return False


def _agp_version(project: Path) -> str | None:
    toml = _read(project / "gradle" / "libs.versions.toml")
    m = re.search(r'^\s*(?:agp|androidGradlePlugin|android-gradle-plugin|androidGradle)\s*=\s*"([^"]+)"', toml, re.M)
    if m:
        return m.group(1)
    blob = "\n".join(_read(project / n) for n in ("build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts"))
    m = re.search(r"com\.android\.tools\.build:gradle:([0-9][^\s\"')]*)", blob)
    if m:
        return m.group(1)
    m = re.search(r"com\.android\.(?:application|library)[\"']\s*\)?\s*version\s*\(?[\"']([^\"']+)", blob)
    return m.group(1) if m else None


def _wrapper_gradle(project: Path) -> str | None:
    props = _read(project / "gradle" / "wrapper" / "gradle-wrapper.properties")
    m = re.search(r"gradle-(\d+(?:\.\d+){1,2})-(?:bin|all)\.zip", props)
    return m.group(1) if m else None


def _detect_android(project: Path, bundled: str) -> Detection:
    mods = _modules(project)
    app_mod = None
    app_dir = None
    for mod in mods:
        d = _module_dir(project, mod)
        if d and _is_app_module(d):
            if app_mod is None or mod.strip(":") == "app":
                app_mod, app_dir = mod, d
    warnings: list[str] = []
    if app_mod is None:
        warnings.append("No application module was identified in settings.gradle; Gradle will run `assembleDebug` for the whole build.")
    if (project / "package.json").is_file():
        pj = _read(project / "package.json")
        if "react-native" in pj:
            return Detection("unsupported", None, "This is a React Native project. It needs Node.js, node_modules and the React Native Gradle plugin, which this converter does not provide.")
        if "capacitor" in pj or "cordova" in pj:
            warnings.append("Capacitor/Cordova project detected: only the android/ folder is built. It must already contain the synced web assets (run `npx cap sync` first) or the app will be empty.")
    agp = _agp_version(project)
    wrapper = _wrapper_gradle(project)
    gradle = required_gradle(agp, wrapper, bundled)
    has_wrapper = (project / "gradlew").is_file()
    if not has_wrapper:
        warnings.append(f"No Gradle wrapper (gradlew) found; Gradle {gradle} will be supplied automatically.")
    info = {"modules": mods, "app_module": app_mod, "agp": agp, "gradle": gradle,
            "has_wrapper": has_wrapper, "kotlin_dsl": (project / "settings.gradle.kts").is_file()}
    det = Detection("android", project, warnings=warnings, info=info)
    det.info["_app_dir"] = str(app_dir) if app_dir else None  # internal; stripped before sending
    return det


# ------------------------------------------------------------------ Web ------

def _find_index(root: Path) -> tuple[Path | None, list[str]]:
    htmls: list[tuple[int, str, Path]] = []
    for d, depth, _, files in _walk(root, 4, _SKIP):
        for f in files:
            if f.lower().endswith((".html", ".htm")):
                htmls.append((depth, f, d / f))
    idx = [h for h in htmls if h[1].lower() in ("index.html", "index.htm")]
    if idx:
        def key(h):
            rel = h[2].relative_to(root).parts
            pref = 0 if any(p in _WEB_PREFER for p in rel[:-1]) else 1
            return (h[0], pref, str(h[2]))
        return sorted(idx, key=key)[0][2], []
    if htmls:
        shallow = [h for h in htmls if h[0] == min(x[0] for x in htmls)]
        if len(shallow) == 1:
            return shallow[0][2], [f"No index.html found; using {shallow[0][1]} as the start page."]
        return None, [h[1] for h in shallow][:10]
    return None, []


def _scan_web(webroot: Path) -> tuple[int, int, bool]:
    files = size = 0
    external = False
    pat = re.compile(r"""(?:src|href)\s*=\s*["']https?://(?!www\.w3\.org)|url\(\s*["']?https?://|@import\s+["']https?://|fetch\(\s*["']https?://""", re.I)
    scanned = 0
    for d, _, _, fs in _walk(webroot, 30, _SKIP):
        for f in fs:
            files += 1
            p = d / f
            try:
                size += p.stat().st_size
            except OSError:
                continue
            if not external and scanned < 60 and f.lower().endswith((".html", ".htm", ".css", ".js", ".mjs")):
                scanned += 1
                if pat.search(_read(p, 400_000)):
                    external = True
    return files, size, external


def _detect_web(root: Path) -> Detection:
    index, extra = _find_index(root)
    if index is None:
        if extra:
            return Detection("unknown", None, "No index.html found. Rename your start page to index.html. HTML files found: " + ", ".join(extra))
        return Detection("unknown", None, "No HTML files found.")
    webroot = index.parent
    warnings = list(extra)
    text = _read(index, 200_000)
    if re.search(r"""<script[^>]+type=["']module["'][^>]+src=["']/?src/""", text, re.I) or re.search(r"""src=["']/src/[^"']+\.(?:jsx?|tsx?)["']""", text):
        warnings.append("This index.html references unbuilt source files (src/*.jsx/tsx). Run your build (e.g. `npm run build`) and upload the dist/ or build/ output instead, otherwise the app will be blank.")
    if re.search(r"""(?:src|href)\s*=\s*["']file:///""", text, re.I):
        warnings.append("The page references file:/// URLs, which will not work inside the app.")
    files, size, external = _scan_web(webroot)
    title = ""
    m = re.search(r"<title[^>]*>(.*?)</title>", text, re.I | re.S)
    if m:
        title = " ".join(html.unescape(m.group(1)).split())[:40]
    info = {"entry": index.name, "files": files, "bytes": size, "uses_external_resources": external,
            "suggested_name": title or "My Web App"}
    return Detection("web", webroot, warnings=warnings, info=info)


# ---------------------------------------------------------------- main -------

def detect(extracted: Path, bundled_gradle: str) -> Detection:
    settings = _find_settings(extracted)
    if settings is not None:
        return _detect_android(settings, bundled_gradle)

    top = list(_walk(extracted, 3, _SKIP))
    names = {f.lower() for _, _, _, fs in top for f in fs}
    if "pubspec.yaml" in names:
        return Detection("unsupported", None, "This is a Flutter project. Building it requires the Flutter SDK (`flutter build apk`), which this converter does not include.")
    pkg = next((d / "package.json" for d, _, _, fs in top if "package.json" in fs), None)
    pkg_txt = _read(pkg) if pkg else ""
    if "react-native" in pkg_txt:
        return Detection("unsupported", None, "This is a React Native project; it needs Node.js tooling and a generated android/ folder. Upload the android/ project or use a RN build service.")
    web = _detect_web(extracted)
    if web.kind == "web":
        if pkg and "build" in pkg_txt and web.root == extracted:
            web.warnings.append("A package.json is present. If this is a framework project, upload its built output (dist/ or build/) rather than the source.")
        return web
    if any(n.endswith((".apk", ".aab")) for n in names):
        return Detection("unsupported", None, "The ZIP already contains an APK/AAB; there is nothing to convert.")
    if pkg:
        return Detection("unsupported", None, "This looks like a Node.js source project with no built HTML output. Run the build and upload the dist/ or build/ folder (it must contain index.html).")
    if "build.gradle" in names or "build.gradle.kts" in names:
        return Detection("unsupported", None, "A Gradle build file was found but no settings.gradle(.kts). Include the complete Android Studio project root.")
    return web  # "unknown" with the reason from _detect_web
